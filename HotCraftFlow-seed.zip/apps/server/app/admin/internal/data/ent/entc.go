//go:build ignore

package main

import (
	"log"

	"entgo.io/ent/entc"
	"entgo.io/ent/entc/gen"
)

func main() {
	if err := entc.Generate("./schema", &gen.Config{
		Features: []gen.Feature{
			gen.FeatureEntQL,
			gen.FeatureModifier,
			gen.FeaturePrivacy,
		},
	}); err != nil {
		log.Fatal(err)
	}
}
